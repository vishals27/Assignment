# Dynamic CNAPP Dashboard (React + Node.js)

An interactive, responsive Cloud Security (CNAPP) Dashboard built according to the assignment requirements using **React**, **Node.js (Express)**, **Tailwind CSS**, and **Recharts**.

---

## ✨ Features Implemented

1. **Dynamic JSON-Driven Architecture (Requirement 1 & 2)**
   - Dashboard categories and widgets are dynamically structured and rendered via JSON.
   - Categories include:
     - `CSPM Executive Dashboard`
     - `CWPP Dashboard`
     - `Registry Scan`
     - `Ticket Alerts Dashboard`
   - Real-time dynamic addition and removal of widgets across any section/category.

2. **Add Widget Experience (Requirement 4)**
   - **Slide-out Drawer / Modal**: Clicking **+ Add Widget** opens the panel as shown in the design specification (Page 2 & Page 3).
   - Categorized tabs (`CSPM`, `CWPP`, `Image`, `Ticket`).
   - Checkbox-based selection to add or remove widgets from categories.
   - Form allowing users to input **Widget Name** and **Widget Text / Content**, which adds it into that category list and dashboard.
   - **Inline Quick-Add**: Each category also features an intuitive dashed "+ Add Widget" card for rapid inline additions.

3. **Widget Removal (Requirement 5)**
   - Each widget has a **cross icon (`X`)** in the upper right header to remove it directly from that category.
   - Users can also uncheck widgets within the "+ Add Widget" slide-out category drawer.

4. **Global Widget Search (Requirement 6)**
   - Header search bar (`Search anything...`) filters all widgets in real-time across all categories by widget title or content text.

5. **Visual Parity with Design Spec (Page 1)**
   - **Donut Charts**: Multi-segment interactive donut charts with center count & sub-label (e.g. `Cloud Accounts`, `Cloud Account Risk Assessment`).
   - **Segmented Horizontal Bar Charts**: Multi-color severity bars with legends (e.g. `Image Risk Assessment`, `Image Security Issues`).
   - **Empty State Charts**: Clean placeholder ("No Graph data available!").
   - **Breadcrumbs & Filter Pills**: Includes `Home > Dashboard V2`, time filter dropdown (`Last 2 days`), and reset controls.

6. **Local State & Backend Persistence (Requirement 2 & Development Requirements)**
   - React Context API + LocalStorage for instant client-side state management.
   - Express (Node.js) REST API endpoints to load, add, delete, and synchronize dashboard widget states persistently.

---

## 🚀 How to Run the Application Locally

### Prerequisites
- **Node.js**: v18.0.0 or higher
- **npm**: v9.0.0 or higher

### Step 1: Install Dependencies

From the project root:

```bash
# Install backend dependencies
cd server
npm install

# Install frontend dependencies
cd ../client
npm install
```

---

### Step 2: Start the Backend Server (Node.js & Express)

In your first terminal:

```bash
cd server
node server.js
```

The Express API server will start on **`http://localhost:5000`**.

---

### Step 3: Start the Frontend Client (React + Vite)

In a second terminal:

```bash
cd client
npm run dev
```

The frontend application will be accessible at:
👉 **`http://localhost:3000`** (or `http://localhost:5173` if port 3000 is occupied).

---

## 🛠️ Project Structure

```text
├── server/
│   ├── server.js              # Express API server with CRUD routes
│   ├── dashboardData.json     # Dynamic JSON data store
│   └── package.json           # Server dependencies (express, cors)
├── client/
│   ├── src/
│   │   ├── context/
│   │   │   └── DashboardContext.jsx   # State management (Context + localStorage + API sync)
│   │   ├── components/
│   │   │   ├── Header.jsx             # Top Navbar, search input, action controls
│   │   │   ├── CategorySection.jsx    # Category grid & inline quick-add card
│   │   │   ├── Widget.jsx             # Donut, horizontal bar, empty & text widgets
│   │   │   └── AddWidgetDrawer.jsx    # Slide-over modal with tabs & checkboxes
│   │   ├── App.jsx                    # Main dashboard layout & search filter
│   │   ├── main.jsx                   # React root entry point
│   │   └── index.css                  # Tailwind styles
│   ├── package.json
│   └── vite.config.js
└── README.md
```

---

## 📡 API Endpoints

- `GET /api/dashboard`: Fetch categories and widgets JSON structure.
- `POST /api/categories/:categoryId/widgets`: Add a new widget with `name` and `text`.
- `DELETE /api/categories/:categoryId/widgets/:widgetId`: Remove a widget from a specific category.
- `PUT /api/categories/sync`: Sync categories and checked widgets from the drawer.
- `POST /api/dashboard/reset`: Reset the dashboard back to the initial assignment layout.
