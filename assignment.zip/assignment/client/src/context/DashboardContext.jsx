import React, { createContext, useContext, useState, useEffect } from 'react';

const DashboardContext = createContext();

const initialFallbackData = {
  categories: [
    {
      id: "cspm",
      name: "CSPM Executive Dashboard",
      shortCode: "CSPM",
      widgets: [
        {
          id: "w-cloud-accounts",
          name: "Cloud Accounts",
          text: "Connected (2), Not Connected (2)",
          type: "donut",
          chartData: {
            centerLabel: "2",
            centerSub: "Total",
            items: [
              { name: "Connected", value: 2, color: "#3B82F6" },
              { name: "Not Connected", value: 2, color: "#93C5FD" }
            ]
          }
        },
        {
          id: "w-risk-assessment",
          name: "Cloud Account Risk Assessment",
          text: "Failed (1689), Warning (681), Not available (36), Passed (7253)",
          type: "donut",
          chartData: {
            centerLabel: "9659",
            centerSub: "Total",
            items: [
              { name: "Failed", value: 1689, color: "#EF4444" },
              { name: "Warning", value: 681, color: "#F59E0B" },
              { name: "Not available", value: 36, color: "#CBD5E1" },
              { name: "Passed", value: 7253, color: "#10B981" }
            ]
          }
        }
      ]
    },
    {
      id: "cwpp",
      name: "CWPP Dashboard",
      shortCode: "CWPP",
      widgets: [
        {
          id: "w-top5-namespace",
          name: "Top 5 Namespace Specific Alerts",
          text: "No Graph data available!",
          type: "empty-chart"
        },
        {
          id: "w-workload-alerts",
          name: "Workload Alerts",
          text: "No Graph data available!",
          type: "empty-chart"
        }
      ]
    },
    {
      id: "registry",
      name: "Registry Scan",
      shortCode: "Image",
      widgets: [
        {
          id: "w-image-risk",
          name: "Image Risk Assessment",
          text: "1470 Total Vulnerabilities: Critical (9), High (150)",
          type: "horizontal-bar",
          chartData: {
            totalCount: 1470,
            totalLabel: "Total Vulnerabilities",
            items: [
              { name: "Critical", value: 9, color: "#B91C1C" },
              { name: "High", value: 150, color: "#F97316" },
              { name: "Medium", value: 600, color: "#FBBF24" },
              { name: "Low", value: 711, color: "#CBD5E1" }
            ]
          }
        },
        {
          id: "w-image-security",
          name: "Image Security Issues",
          text: "2 Total Images: Critical (1), High (1)",
          type: "horizontal-bar",
          chartData: {
            totalCount: 2,
            totalLabel: "Total Images",
            items: [
              { name: "Critical", value: 1, color: "#B91C1C" },
              { name: "High", value: 1, color: "#F97316" }
            ]
          }
        }
      ]
    },
    {
      id: "ticket",
      name: "Ticket Alerts Dashboard",
      shortCode: "Ticket",
      widgets: []
    }
  ]
};

export const DashboardProvider = ({ children }) => {
  const [categories, setCategories] = useState(() => {
    const saved = localStorage.getItem('dashboard_data');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error(e);
      }
    }
    return initialFallbackData.categories;
  });

  const [searchQuery, setSearchQuery] = useState('');
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);
  const [selectedDrawerCategory, setSelectedDrawerCategory] = useState('cspm');
  const [loading, setLoading] = useState(false);

  // Sync state to local storage
  useEffect(() => {
    localStorage.setItem('dashboard_data', JSON.stringify(categories));
  }, [categories]);

  // Try fetching from backend API on mount if available
  useEffect(() => {
    fetch('/api/dashboard')
      .then(res => {
        if (res.ok) return res.json();
        throw new Error('Backend not available');
      })
      .then(data => {
        if (data && data.categories) {
          // If local storage is empty, initialize from API
          if (!localStorage.getItem('dashboard_data')) {
            setCategories(data.categories);
          }
        }
      })
      .catch(err => {
        console.log('Running locally without active backend or offline:', err.message);
      });
  }, []);

  // Remove widget by categoryId and widgetId
  const removeWidget = async (categoryId, widgetId) => {
    setCategories(prev =>
      prev.map(cat => {
        if (cat.id === categoryId) {
          return {
            ...cat,
            widgets: cat.widgets.filter(w => w.id !== widgetId)
          };
        }
        return cat;
      })
    );

    // Also inform backend if available
    try {
      await fetch(`/api/categories/${categoryId}/widgets/${widgetId}`, {
        method: 'DELETE'
      });
    } catch (err) {
      // offline fallback
    }
  };

  // Add widget directly
  const addWidget = async (categoryId, name, text) => {
    const newWidget = {
      id: 'w-' + Date.now() + '-' + Math.random().toString(36).substr(2, 4),
      name: name || 'New Custom Widget',
      text: text || 'Custom widget content description',
      type: 'text'
    };

    setCategories(prev =>
      prev.map(cat => {
        if (cat.id === categoryId) {
          return {
            ...cat,
            widgets: [...cat.widgets, newWidget]
          };
        }
        return cat;
      })
    );

    try {
      await fetch(`/api/categories/${categoryId}/widgets`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, text })
      });
    } catch (err) {
      // offline fallback
    }
  };

  // Batch sync categories (e.g. from Manage / Add Widget drawer)
  const syncCategories = async (newCategories) => {
    setCategories(newCategories);
    try {
      await fetch('/api/categories/sync', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ categories: newCategories })
      });
    } catch (err) {
      // offline fallback
    }
  };

  const resetDashboard = async () => {
    setCategories(initialFallbackData.categories);
    localStorage.removeItem('dashboard_data');
    try {
      await fetch('/api/dashboard/reset', { method: 'POST' });
    } catch (err) {}
  };

  return (
    <DashboardContext.Provider
      value={{
        categories,
        setCategories,
        searchQuery,
        setSearchQuery,
        isDrawerOpen,
        setIsDrawerOpen,
        selectedDrawerCategory,
        setSelectedDrawerCategory,
        addWidget,
        removeWidget,
        syncCategories,
        resetDashboard,
        initialFallbackData
      }}
    >
      {children}
    </DashboardContext.Provider>
  );
};

export const useDashboard = () => {
  const context = useContext(DashboardContext);
  if (!context) {
    throw new Error('useDashboard must be used within DashboardProvider');
  }
  return context;
};
