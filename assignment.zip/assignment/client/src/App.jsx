import React from 'react';
import { Navbar, DashboardHeader } from './components/Header';
import { CategorySection } from './components/CategorySection';
import { AddWidgetDrawer } from './components/AddWidgetDrawer';
import { useDashboard } from './context/DashboardContext';
import { Search } from 'lucide-react';

function App() {
  const {
    categories,
    searchQuery,
    removeWidget,
    addWidget,
    setIsDrawerOpen,
    setSelectedDrawerCategory
  } = useDashboard();

  // Filter widgets across all categories according to search query (Requirement 6)
  const filteredCategories = categories.map(category => {
    if (!searchQuery.trim()) return category;
    const query = searchQuery.toLowerCase();
    const matchedWidgets = category.widgets.filter(
      w =>
        w.name.toLowerCase().includes(query) ||
        (w.text && w.text.toLowerCase().includes(query))
    );
    return {
      ...category,
      widgets: matchedWidgets
    };
  });

  const totalMatchedWidgets = filteredCategories.reduce(
    (acc, curr) => acc + curr.widgets.length,
    0
  );

  return (
    <div className="min-h-screen bg-[#f0f4f8] text-gray-800 pb-16 font-sans antialiased">
      {/* Top Navigation */}
      <Navbar />

      {/* Main Container */}
      <main className="max-w-7xl mx-auto">
        <DashboardHeader />

        {/* Search Results Alert if searching */}
        {searchQuery && (
          <div className="px-4 sm:px-6 lg:px-8 mb-4">
            <div className="bg-blue-50 border border-blue-200 text-blue-800 px-4 py-2.5 rounded-xl text-xs flex items-center justify-between">
              <span>
                Found <strong>{totalMatchedWidgets}</strong> widget{totalMatchedWidgets === 1 ? '' : 's'} matching "<strong>{searchQuery}</strong>"
              </span>
            </div>
          </div>
        )}

        {/* Dashboard Categories Content */}
        <div className="px-4 sm:px-6 lg:px-8 space-y-6">
          {filteredCategories.map(category => (
            <CategorySection
              key={category.id}
              category={category}
              onRemoveWidget={removeWidget}
              onAddWidgetClick={(catId) => {
                setSelectedDrawerCategory(catId);
                setIsDrawerOpen(true);
              }}
              onQuickAddWidget={addWidget}
            />
          ))}
        </div>
      </main>

      {/* Slide-out Add/Manage Widget Drawer */}
      <AddWidgetDrawer />
    </div>
  );
}

export default App;
