import React from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer } from 'recharts';
import { X, BarChart2 } from 'lucide-react';

export const Widget = ({ widget, categoryId, onRemove }) => {
  // Render content depending on widget type
  const renderContent = () => {
    if (widget.type === 'donut' && widget.chartData) {
      const { items, centerLabel, centerSub } = widget.chartData;
      return (
        <div className="flex items-center justify-between h-44 px-2">
          {/* Donut Chart with center label */}
          <div className="relative w-40 h-40 flex items-center justify-center">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={items}
                  cx="50%"
                  cy="50%"
                  innerRadius={45}
                  outerRadius={65}
                  paddingAngle={2}
                  dataKey="value"
                  stroke="none"
                >
                  {items.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
              </PieChart>
            </ResponsiveContainer>
            <div className="absolute flex flex-col items-center justify-center pointer-events-none">
              <span className="text-xl font-bold text-gray-800 leading-tight">{centerLabel}</span>
              {centerSub && <span className="text-xs text-gray-500 font-medium">{centerSub}</span>}
            </div>
          </div>

          {/* Legend */}
          <div className="flex flex-col gap-2 flex-1 pl-4 text-xs">
            {items.map((item, idx) => (
              <div key={idx} className="flex items-center gap-2">
                <span
                  className="w-2.5 h-2.5 rounded-full flex-shrink-0"
                  style={{ backgroundColor: item.color }}
                />
                <span className="text-gray-600 font-medium truncate">
                  {item.name} <span className="font-semibold text-gray-800">({item.value})</span>
                </span>
              </div>
            ))}
          </div>
        </div>
      );
    }

    if (widget.type === 'horizontal-bar' && widget.chartData) {
      const { items, totalCount, totalLabel } = widget.chartData;
      const total = items.reduce((acc, curr) => acc + curr.value, 0);

      return (
        <div className="flex flex-col justify-center h-44 px-4 gap-4">
          <div>
            <span className="text-2xl font-bold text-gray-800">{totalCount} </span>
            <span className="text-xs text-gray-500 font-medium">{totalLabel}</span>
          </div>

          {/* Segmented Progress Bar */}
          <div className="w-full h-3 rounded-full overflow-hidden flex bg-gray-100">
            {items.map((item, idx) => {
              const widthPct = total > 0 ? (item.value / total) * 100 : 0;
              return (
                <div
                  key={idx}
                  style={{ width: `${widthPct}%`, backgroundColor: item.color }}
                  title={`${item.name}: ${item.value}`}
                />
              );
            })}
          </div>

          {/* Legend */}
          <div className="flex flex-wrap gap-x-4 gap-y-2 text-xs">
            {items.map((item, idx) => (
              <div key={idx} className="flex items-center gap-1.5">
                <span
                  className="w-2.5 h-2.5 rounded-full flex-shrink-0"
                  style={{ backgroundColor: item.color }}
                />
                <span className="text-gray-600">
                  {item.name} <span className="font-semibold text-gray-800">({item.value})</span>
                </span>
              </div>
            ))}
          </div>
        </div>
      );
    }

    if (widget.type === 'empty-chart') {
      return (
        <div className="flex flex-col items-center justify-center h-44 text-gray-400 gap-2">
          <div className="p-3 bg-gray-50 rounded-full text-gray-300">
            <BarChart2 className="w-9 h-9" />
          </div>
          <p className="text-xs text-gray-400 font-medium">{widget.text || 'No Graph data available!'}</p>
        </div>
      );
    }

    // Default text widget
    return (
      <div className="flex flex-col justify-center items-start h-44 px-4">
        <p className="text-sm text-gray-700 leading-relaxed font-normal bg-gray-50 p-4 rounded-lg w-full border border-gray-100">
          {widget.text || 'Random widget text or notes for display.'}
        </p>
      </div>
    );
  };

  return (
    <div className="relative bg-white rounded-2xl border border-gray-100 shadow-xs hover:shadow-md transition-shadow duration-200 flex flex-col p-4 h-[250px] overflow-hidden group">
      {/* Header */}
      <div className="flex items-center justify-between pb-2 mb-1">
        <h3 className="font-semibold text-sm text-gray-800 tracking-tight truncate pr-6" title={widget.name}>
          {widget.name}
        </h3>
        {/* Remove cross icon (Requirement 5) */}
        <button
          onClick={() => onRemove(categoryId, widget.id)}
          className="text-gray-400 hover:text-red-500 hover:bg-red-50 rounded-full p-1 transition-colors"
          title="Remove widget"
          aria-label="Remove widget"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* Widget Body */}
      <div className="flex-1 flex flex-col justify-center">
        {renderContent()}
      </div>
    </div>
  );
};
