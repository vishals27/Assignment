import React, { useState, useEffect } from 'react';
import { X, Plus, Trash2 } from 'lucide-react';
import { useDashboard } from '../context/DashboardContext';

export const AddWidgetDrawer = () => {
  const {
    isDrawerOpen,
    setIsDrawerOpen,
    categories,
    syncCategories,
    selectedDrawerCategory,
    setSelectedDrawerCategory,
    initialFallbackData
  } = useDashboard();

  // Local state for categories inside drawer to allow confirming or canceling changes
  const [draftCategories, setDraftCategories] = useState([]);
  const [activeTab, setActiveTab] = useState(selectedDrawerCategory || 'cspm');
  const [newWidgetName, setNewWidgetName] = useState('');
  const [newWidgetText, setNewWidgetText] = useState('');

  // Collect pool of available widgets from current categories + defaults
  useEffect(() => {
    if (isDrawerOpen) {
      setActiveTab(selectedDrawerCategory || (categories[0] && categories[0].id) || 'cspm');
      // Clone current categories to draft
      setDraftCategories(JSON.parse(JSON.stringify(categories)));
      setNewWidgetName('');
      setNewWidgetText('');
    }
  }, [isDrawerOpen, categories, selectedDrawerCategory]);

  if (!isDrawerOpen) return null;

  // Active category in draft
  const currentCategory = draftCategories.find(c => c.id === activeTab) || draftCategories[0];

  // Toggle widget checkbox in active category
  const toggleWidget = (widgetId) => {
    setDraftCategories(prev =>
      prev.map(cat => {
        if (cat.id === activeTab) {
          const exists = cat.widgets.some(w => w.id === widgetId);
          if (exists) {
            // Remove it
            return {
              ...cat,
              widgets: cat.widgets.filter(w => w.id !== widgetId)
            };
          } else {
            // Find widget from initialFallbackData or other categories
            let found = null;
            for (const c of initialFallbackData.categories) {
              const match = c.widgets.find(w => w.id === widgetId);
              if (match) {
                found = match;
                break;
              }
            }
            if (!found) {
              found = {
                id: widgetId,
                name: 'Custom Widget',
                text: 'Widget content',
                type: 'text'
              };
            }
            return {
              ...cat,
              widgets: [...cat.widgets, found]
            };
          }
        }
        return cat;
      })
    );
  };

  // Add brand new custom widget to current category
  const handleAddNewWidget = (e) => {
    e.preventDefault();
    if (!newWidgetName.trim()) return;

    const newWidget = {
      id: 'w-' + Date.now() + '-' + Math.random().toString(36).substr(2, 4),
      name: newWidgetName.trim(),
      text: newWidgetText.trim() || 'Custom text description',
      type: 'text'
    };

    setDraftCategories(prev =>
      prev.map(cat => {
        if (cat.id === activeTab) {
          return {
            ...cat,
            widgets: [...cat.widgets, newWidget]
          };
        }
        return cat;
      })
    );

    setNewWidgetName('');
    setNewWidgetText('');
  };

  // Confirm changes
  const handleConfirm = () => {
    syncCategories(draftCategories);
    setIsDrawerOpen(false);
  };

  // Cancel changes
  const handleCancel = () => {
    setIsDrawerOpen(false);
  };

  // Look for all template widgets available for this tab
  // (combining default templates plus any widgets already in draft)
  const defaultCategoryTemplate = initialFallbackData.categories.find(c => c.id === activeTab);
  const templateWidgets = defaultCategoryTemplate ? defaultCategoryTemplate.widgets : [];
  
  // Combine unique widgets in draft currentCategory and template
  const allWidgetCandidates = [...(currentCategory ? currentCategory.widgets : [])];
  templateWidgets.forEach(tw => {
    if (!allWidgetCandidates.some(w => w.id === tw.id)) {
      allWidgetCandidates.push(tw);
    }
  });

  return (
    <div className="fixed inset-0 z-50 overflow-hidden flex justify-end">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-black/40 backdrop-blur-xs transition-opacity"
        onClick={handleCancel}
      />

      {/* Slide-over Drawer Panel */}
      <div className="relative w-full max-w-lg bg-white h-full shadow-2xl flex flex-col z-10 animate-in slide-in-from-right duration-200">
        {/* Drawer Header */}
        <div className="bg-blue-950 text-white px-6 py-4 flex items-center justify-between">
          <h2 className="text-base font-semibold">Add Widget</h2>
          <button
            onClick={handleCancel}
            className="text-gray-300 hover:text-white p-1 rounded-md hover:bg-blue-900 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Drawer Subtitle */}
        <div className="px-6 pt-4 pb-2 border-b border-gray-100">
          <p className="text-xs text-gray-500 font-medium">
            Personalise your dashboard by adding the following widget
          </p>

          {/* Category Tabs (CSPM, CWPP, Image, Ticket) */}
          <div className="flex gap-6 mt-4 border-b border-gray-200 text-xs font-semibold">
            {draftCategories.map(cat => {
              const isActive = cat.id === activeTab;
              return (
                <button
                  key={cat.id}
                  onClick={() => setActiveTab(cat.id)}
                  className={`pb-2.5 transition-colors relative cursor-pointer ${
                    isActive
                      ? 'text-blue-950 font-bold border-b-2 border-blue-950'
                      : 'text-gray-400 hover:text-gray-700'
                  }`}
                >
                  {cat.shortCode || cat.name.split(' ')[0]}
                </button>
              );
            })}
          </div>
        </div>

        {/* Drawer Content: Widget Checkbox List */}
        <div className="flex-1 overflow-y-auto px-6 py-4 space-y-3">
          <div className="text-xs font-bold text-gray-600 mb-2 uppercase tracking-wider">
            Available Widgets in {currentCategory ? currentCategory.name : ''}
          </div>

          {allWidgetCandidates.length > 0 ? (
            <div className="space-y-2">
              {allWidgetCandidates.map(widget => {
                const isChecked = currentCategory?.widgets.some(w => w.id === widget.id);
                return (
                  <label
                    key={widget.id}
                    className="flex items-center gap-3 p-3 rounded-lg border border-gray-200 hover:border-blue-400 hover:bg-blue-50/20 cursor-pointer transition-colors"
                  >
                    <input
                      type="checkbox"
                      checked={isChecked}
                      onChange={() => toggleWidget(widget.id)}
                      className="w-4 h-4 text-blue-600 rounded border-gray-300 focus:ring-blue-500 cursor-pointer"
                    />
                    <div className="flex-1 min-w-0">
                      <div className="text-xs font-semibold text-gray-800 truncate">
                        {widget.name}
                      </div>
                      <div className="text-[11px] text-gray-500 truncate">
                        {widget.text || 'Widget preview text'}
                      </div>
                    </div>
                  </label>
                );
              })}
            </div>
          ) : (
            <div className="text-xs text-gray-400 italic py-2">
              No widgets in this category yet. Create one below!
            </div>
          )}

          {/* Form to Add Brand New Widget (Requirement 4) */}
          <div className="mt-8 pt-4 border-t border-gray-100">
            <h3 className="text-xs font-bold text-gray-700 mb-3 flex items-center gap-1.5 uppercase tracking-wider">
              <Plus className="w-3.5 h-3.5 text-blue-600" /> Create Custom Widget
            </h3>
            <form onSubmit={handleAddNewWidget} className="space-y-3 bg-gray-50 p-3.5 rounded-xl border border-gray-200">
              <div>
                <label className="block text-[11px] font-semibold text-gray-600 mb-1">
                  Widget Name *
                </label>
                <input
                  type="text"
                  placeholder="e.g. Server Latency"
                  value={newWidgetName}
                  onChange={(e) => setNewWidgetName(e.target.value)}
                  className="w-full text-xs px-3 py-2 bg-white border border-gray-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-600"
                  required
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-gray-600 mb-1">
                  Widget Text / Information
                </label>
                <textarea
                  placeholder="e.g. Average latency: 24ms, Uptime: 99.98%"
                  value={newWidgetText}
                  onChange={(e) => setNewWidgetText(e.target.value)}
                  rows={2}
                  className="w-full text-xs px-3 py-2 bg-white border border-gray-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-600 resize-none"
                />
              </div>

              <button
                type="submit"
                className="w-full py-2 bg-blue-900 text-white rounded-lg text-xs font-medium hover:bg-blue-800 transition-colors shadow-xs"
              >
                + Add To Category List
              </button>
            </form>
          </div>
        </div>

        {/* Drawer Footer Buttons */}
        <div className="p-4 border-t border-gray-200 bg-gray-50 flex items-center justify-end gap-3">
          <button
            type="button"
            onClick={handleCancel}
            className="px-5 py-2 border border-gray-300 rounded-lg text-xs font-semibold text-gray-700 bg-white hover:bg-gray-100 transition-colors shadow-2xs"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={handleConfirm}
            className="px-5 py-2 bg-blue-950 text-white rounded-lg text-xs font-semibold hover:bg-blue-900 transition-colors shadow-sm"
          >
            Confirm
          </button>
        </div>
      </div>
    </div>
  );
};
