import React, { useState } from 'react';
import { Plus, X } from 'lucide-react';
import { Widget } from './Widget';

export const CategorySection = ({ category, onRemoveWidget, onAddWidgetClick, onQuickAddWidget }) => {
  const [showQuickAdd, setShowQuickAdd] = useState(false);
  const [widgetName, setWidgetName] = useState('');
  const [widgetText, setWidgetText] = useState('');

  const handleQuickSubmit = (e) => {
    e.preventDefault();
    if (!widgetName.trim()) return;
    onQuickAddWidget(category.id, widgetName, widgetText);
    setWidgetName('');
    setWidgetText('');
    setShowQuickAdd(false);
  };

  return (
    <section className="mb-8">
      {/* Category Title */}
      <h2 className="text-base font-bold text-gray-800 mb-3 tracking-tight">
        {category.name}
      </h2>

      {/* Grid of Widgets */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {category.widgets.map((widget) => (
          <Widget
            key={widget.id}
            widget={widget}
            categoryId={category.id}
            onRemove={onRemoveWidget}
          />
        ))}

        {/* Add Widget Card */}
        {!showQuickAdd ? (
          <div
            onClick={() => setShowQuickAdd(true)}
            className="bg-white/80 rounded-2xl border-2 border-dashed border-gray-200 hover:border-blue-400 hover:bg-blue-50/20 transition-all cursor-pointer flex flex-col items-center justify-center p-6 h-[250px] group shadow-2xs"
          >
            <div className="flex items-center gap-2 px-4 py-2 border border-gray-300 rounded-lg text-xs font-semibold text-gray-600 bg-white group-hover:bg-blue-50 group-hover:border-blue-400 group-hover:text-blue-600 transition-colors shadow-2xs">
              <Plus className="w-4 h-4 text-gray-500 group-hover:text-blue-600" />
              <span>+ Add Widget</span>
            </div>
          </div>
        ) : (
          <div className="bg-white rounded-2xl border border-blue-200 shadow-md p-5 h-[250px] flex flex-col justify-between">
            <div className="flex items-center justify-between pb-2 border-b border-gray-100">
              <span className="text-xs font-bold uppercase tracking-wider text-blue-600">Quick Add Widget</span>
              <button
                onClick={() => setShowQuickAdd(false)}
                className="text-gray-400 hover:text-gray-600"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleQuickSubmit} className="flex flex-col gap-2.5 my-auto">
              <input
                type="text"
                placeholder="Widget Name (e.g. Server Latency)"
                value={widgetName}
                onChange={(e) => setWidgetName(e.target.value)}
                className="w-full text-xs px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-500"
                autoFocus
                required
              />
              <textarea
                placeholder="Widget Text / Notes"
                value={widgetText}
                rows={2}
                onChange={(e) => setWidgetText(e.target.value)}
                className="w-full text-xs px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-500 resize-none"
              />
              <div className="flex justify-end gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => setShowQuickAdd(false)}
                  className="px-3 py-1.5 text-xs text-gray-500 hover:bg-gray-100 rounded-lg"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-3 py-1.5 text-xs bg-blue-900 text-white font-medium rounded-lg hover:bg-blue-800 shadow-xs"
                >
                  Add
                </button>
              </div>
            </form>
          </div>
        )}
      </div>
    </section>
  );
};
