import React from 'react';
import { Search, Bell, User, RotateCcw, Plus, Clock, MoreVertical } from 'lucide-react';
import { useDashboard } from '../context/DashboardContext';

export const Navbar = () => {
  const { searchQuery, setSearchQuery } = useDashboard();

  return (
    <header className="bg-white border-b border-gray-200 sticky top-0 z-30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-14 flex items-center justify-between gap-4">
        {/* Breadcrumb */}
        <div className="flex items-center gap-2 text-xs text-gray-400 font-medium whitespace-nowrap">
          <span className="hover:text-gray-600 cursor-pointer">Home</span>
          <span>&gt;</span>
          <span className="text-blue-900 font-semibold cursor-pointer">Dashboard V2</span>
        </div>

        {/* Global Search Bar (Requirement 6) */}
        <div className="flex-1 max-w-md mx-4">
          <div className="relative">
            <Search className="w-4 h-4 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search anything..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full text-xs pl-9 pr-4 py-1.5 bg-blue-50/60 border border-transparent hover:border-gray-300 focus:border-blue-500 focus:bg-white rounded-md focus:outline-none transition-all placeholder:text-gray-400 text-gray-700"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-xs text-gray-400 hover:text-gray-600"
              >
                ×
              </button>
            )}
          </div>
        </div>

        {/* Actions / Profile */}
        <div className="flex items-center gap-3">
          <button className="text-gray-500 hover:text-gray-700 p-1.5 rounded-full hover:bg-gray-100 transition-colors">
            <Bell className="w-4 h-4" />
          </button>
          <div className="w-7 h-7 rounded-full bg-blue-100 text-blue-900 font-bold flex items-center justify-center text-xs border border-blue-200">
            <User className="w-4 h-4" />
          </div>
        </div>
      </div>
    </header>
  );
};

export const DashboardHeader = () => {
  const { setIsDrawerOpen, setSelectedDrawerCategory, resetDashboard } = useDashboard();

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-6 pb-4">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        {/* Title */}
        <h1 className="text-lg font-bold text-gray-900 tracking-tight">
          CNAPP Dashboard
        </h1>

        {/* Top Control Buttons */}
        <div className="flex items-center flex-wrap gap-2.5">
          {/* Add Widget Button */}
          <button
            onClick={() => {
              setSelectedDrawerCategory('cspm');
              setIsDrawerOpen(true);
            }}
            className="flex items-center gap-1.5 bg-white border border-gray-300 hover:border-gray-400 text-gray-700 text-xs font-semibold px-3.5 py-1.5 rounded-lg shadow-2xs hover:bg-gray-50 transition-all cursor-pointer"
          >
            <span>Add Widget</span>
            <Plus className="w-3.5 h-3.5 text-gray-500" />
          </button>

          {/* Reset / Refresh Button */}
          <button
            onClick={resetDashboard}
            title="Reset to default dashboard"
            className="p-1.5 bg-white border border-gray-300 hover:bg-gray-50 rounded-lg text-gray-600 shadow-2xs transition-colors"
          >
            <RotateCcw className="w-4 h-4" />
          </button>

          {/* Menu Button */}
          <button
            title="More options"
            className="p-1.5 bg-white border border-gray-300 hover:bg-gray-50 rounded-lg text-gray-600 shadow-2xs transition-colors"
          >
            <MoreVertical className="w-4 h-4" />
          </button>

          {/* Time Filter Pill */}
          <div className="flex items-center gap-1.5 bg-white border border-blue-900 text-blue-900 px-3 py-1.5 rounded-lg text-xs font-bold shadow-2xs cursor-pointer">
            <Clock className="w-3.5 h-3.5 text-blue-900" />
            <span>|</span>
            <span>Last 2 days</span>
            <span className="text-[10px]">▼</span>
          </div>
        </div>
      </div>
    </div>
  );
};
