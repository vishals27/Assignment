const express = require('express');
const cors = require('cors');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 5000;
const DATA_FILE = path.join(__dirname, 'dashboardData.json');

app.use(cors());
app.use(express.json());

// Initial default JSON data if dashboardData.json does not exist
const initialData = {
  categories: [
    {
      id: "cspm",
      name: "CSPM Executive Dashboard",
      shortCode: "CSPM",
      widgets: [
        {
          id: "w-cloud-accounts",
          name: "Cloud Accounts",
          text: "Connected (2), Not Connected (2)",
          type: "donut",
          chartData: {
            centerLabel: "2",
            centerSub: "Total",
            items: [
              { name: "Connected", value: 2, color: "#3B82F6" },
              { name: "Not Connected", value: 2, color: "#93C5FD" }
            ]
          }
        },
        {
          id: "w-risk-assessment",
          name: "Cloud Account Risk Assessment",
          text: "Failed (1689), Warning (681), Not available (36), Passed (7253)",
          type: "donut",
          chartData: {
            centerLabel: "9659",
            centerSub: "Total",
            items: [
              { name: "Failed", value: 1689, color: "#EF4444" },
              { name: "Warning", value: 681, color: "#F59E0B" },
              { name: "Not available", value: 36, color: "#CBD5E1" },
              { name: "Passed", value: 7253, color: "#10B981" }
            ]
          }
        }
      ]
    },
    {
      id: "cwpp",
      name: "CWPP Dashboard",
      shortCode: "CWPP",
      widgets: [
        {
          id: "w-top5-namespace",
          name: "Top 5 Namespace Specific Alerts",
          text: "No Graph data available!",
          type: "empty-chart"
        },
        {
          id: "w-workload-alerts",
          name: "Workload Alerts",
          text: "No Graph data available!",
          type: "empty-chart"
        }
      ]
    },
    {
      id: "registry",
      name: "Registry Scan",
      shortCode: "Image",
      widgets: [
        {
          id: "w-image-risk",
          name: "Image Risk Assessment",
          text: "1470 Total Vulnerabilities: Critical (9), High (150)",
          type: "horizontal-bar",
          chartData: {
            totalCount: 1470,
            totalLabel: "Total Vulnerabilities",
            items: [
              { name: "Critical", value: 9, color: "#B91C1C" },
              { name: "High", value: 150, color: "#F97316" },
              { name: "Medium", value: 600, color: "#FBBF24" },
              { name: "Low", value: 711, color: "#E2E8F0" }
            ]
          }
        },
        {
          id: "w-image-security",
          name: "Image Security Issues",
          text: "2 Total Images: Critical (1), High (1)",
          type: "horizontal-bar",
          chartData: {
            totalCount: 2,
            totalLabel: "Total Images",
            items: [
              { name: "Critical", value: 1, color: "#B91C1C" },
              { name: "High", value: 1, color: "#F97316" }
            ]
          }
        }
      ]
    },
    {
      id: "ticket",
      name: "Ticket Alerts Dashboard",
      shortCode: "Ticket",
      widgets: []
    }
  ]
};

// Helper to read data
function getDashboardData() {
  if (!fs.existsSync(DATA_FILE)) {
    fs.writeFileSync(DATA_FILE, JSON.stringify(initialData, null, 2));
    return initialData;
  }
  try {
    const raw = fs.readFileSync(DATA_FILE, 'utf8');
    return JSON.parse(raw);
  } catch (err) {
    console.error('Error reading data file:', err);
    return initialData;
  }
}

// Helper to save data
function saveDashboardData(data) {
  fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));
}

// 1. Get entire dashboard categories and widgets
app.get('/api/dashboard', (req, res) => {
  const data = getDashboardData();
  res.json(data);
});

// 2. Add a new widget to a specific category
app.post('/api/categories/:categoryId/widgets', (req, res) => {
  const { categoryId } = req.params;
  const { name, text, type } = req.body;

  if (!name || !name.trim()) {
    return res.status(400).json({ error: 'Widget name is required' });
  }

  const data = getDashboardData();
  const category = data.categories.find(c => c.id === categoryId);

  if (!category) {
    return res.status(404).json({ error: 'Category not found' });
  }

  const newWidget = {
    id: 'w-' + Date.now() + '-' + Math.random().toString(36).substr(2, 4),
    name: name.trim(),
    text: text ? text.trim() : 'Custom Widget Description',
    type: type || 'text'
  };

  category.widgets.push(newWidget);
  saveDashboardData(data);

  res.status(201).json({ widget: newWidget, categories: data.categories });
});

// 3. Remove a widget by categoryId and widgetId
app.delete('/api/categories/:categoryId/widgets/:widgetId', (req, res) => {
  const { categoryId, widgetId } = req.params;
  const data = getDashboardData();
  const category = data.categories.find(c => c.id === categoryId);

  if (!category) {
    return res.status(404).json({ error: 'Category not found' });
  }

  const initialCount = category.widgets.length;
  category.widgets = category.widgets.filter(w => w.id !== widgetId);

  if (category.widgets.length === initialCount) {
    return res.status(404).json({ error: 'Widget not found in this category' });
  }

  saveDashboardData(data);
  res.json({ message: 'Widget removed successfully', categories: data.categories });
});

// 4. Batch update / sync widgets for multiple categories (used by drawer modal checkboxes)
app.put('/api/categories/sync', (req, res) => {
  const { categories } = req.body;
  if (!Array.isArray(categories)) {
    return res.status(400).json({ error: 'Invalid payload, expected categories array' });
  }
  const data = { categories };
  saveDashboardData(data);
  res.json(data);
});

// 5. Reset to default state
app.post('/api/dashboard/reset', (req, res) => {
  saveDashboardData(initialData);
  res.json(initialData);
});

app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
